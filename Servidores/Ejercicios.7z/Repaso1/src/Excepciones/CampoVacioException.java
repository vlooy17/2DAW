/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Excepciones;

/**
 *
 * @author alumno_2DAW
 */
public class CampoVacioException extends Exception{

    public CampoVacioException(String msg) {
        super(msg);
    }
    
}
